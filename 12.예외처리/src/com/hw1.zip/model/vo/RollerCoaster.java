package com.hw1.model.vo;

public class RollerCoaster {
	public static final double CUTHEIGHT = 110;
	public static final int PRICE = 4500;
	public static final int PERMITNUMBER = 2;
	
	public RollerCoaster() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	

}
